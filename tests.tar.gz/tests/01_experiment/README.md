training set: two speakers, 10 minutes each, 7 second utterances.

EMBEDDING_D = 30

Here at iteration 20k, 

2018-02-16 08:37:48.746140: step 20000, loss = 121997.75 (46.1 examples/sec; 2.775 sec/batch, epoch 1777)

In test, no noticeable improvement from iteration 4k.

Next: keep working on two-speaker case, but try with a more data (2 hrs of speech per speaker).

