Step 8000

loss ~ 2 M