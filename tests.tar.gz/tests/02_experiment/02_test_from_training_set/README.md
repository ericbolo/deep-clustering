Step 24000

loss ~1,4M

All data taken from training set.