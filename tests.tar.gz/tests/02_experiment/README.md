training set: two speakers, ~2hrs each, 3-second utterances.

EMBEDDING_D = 35

